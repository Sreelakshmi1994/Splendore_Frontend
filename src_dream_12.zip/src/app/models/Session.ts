export class Session
{
    Session_Id:number;
    Session_Name:string;
constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

