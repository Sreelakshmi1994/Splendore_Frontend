export class MarkStatus
{
    Markstatus_Id:number;
    Markstatus_Name:string;

constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

