export class Intake_Year
{
Intake_Year_Id:number;
Intake_Year_Name:string;
Intake_Year_Status:boolean;
Intake_Year_Selection:boolean;


constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

