export class Mode
{
    Mode_Id:number;
    Mode_Name:string;

constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

