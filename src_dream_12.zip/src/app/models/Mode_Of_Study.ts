export class Mode_Of_Study
{
Mode_Of_Study_Id:number;
Mode_Of_Study_Name:string;
constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

