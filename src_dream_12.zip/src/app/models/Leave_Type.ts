export class Leave_Type
{
Leave_Type_Id:number;
Leave_Type_Name:string;
Users_Id:number;
constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

