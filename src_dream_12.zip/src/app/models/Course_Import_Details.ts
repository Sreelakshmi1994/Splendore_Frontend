export class Course_Import_Details
{
Course_Import_Details_Id:number;
Course_Import_Master_Id:number;
Course_Id:number;
constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

