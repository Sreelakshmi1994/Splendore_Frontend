export class Voucher_Type
{
Voucher_Type_Id:number;
Voucher_Type_Name:string;

constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

