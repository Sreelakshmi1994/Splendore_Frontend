export class Store_Partners
{
Store_Partners_Id:number;
Store_Id:number;
Client_Accounts_Id:number;
Profit_Percentage:number;
Profit_Percentage1:number;
constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

