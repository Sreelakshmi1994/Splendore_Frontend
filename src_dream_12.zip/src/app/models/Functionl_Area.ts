export class Functionl_Area
{
Functionl_Area_Id:number;
Functionl_Area_Name:string;
User_Id:number;
constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

