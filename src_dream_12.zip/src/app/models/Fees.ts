export class Fees
{
    Fees_Id:number;
    Fees_Name:string;
DeleteStatus:number;

constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}
