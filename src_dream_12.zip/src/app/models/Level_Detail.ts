export class Level_Detail
{
Level_Detail_Id:number;
Level_Detail_Name:string;
   
constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

