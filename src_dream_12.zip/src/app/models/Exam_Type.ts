export class Exam_Type
{
    Exam_Type_Id:number;
    Exam_Type_Name:string;
constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

