export class Application_Status
{
Application_Status_Id:number;
Application_Status_Name:string;

constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

