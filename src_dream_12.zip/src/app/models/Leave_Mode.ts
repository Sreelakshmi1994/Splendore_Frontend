export class Leave_Mode
{
    Leave_Mode_Id:number;
    Leave_Mode_Name:string;
    Users_Id:number;
constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

