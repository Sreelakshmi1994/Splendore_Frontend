export class Payment_Status
{
    Payment_Status_Id:number;
    Payment_Status_Name:string;
DeleteStatus:number;
constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

