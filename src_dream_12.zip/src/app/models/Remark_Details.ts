export class Remark_Details
{
    Remark_Details_Id:number;
    Details:string;
constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

