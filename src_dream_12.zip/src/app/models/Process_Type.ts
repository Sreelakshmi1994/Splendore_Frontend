export class Process_Type
{
    Process_Type_Id:number;
    Process_Type_Name:string;
    Delete_Status:number;
constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

