export class Leave_Count
{Login_User_Id: number;
    Balance_PL:number;
    Balance_CL:number;
constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

