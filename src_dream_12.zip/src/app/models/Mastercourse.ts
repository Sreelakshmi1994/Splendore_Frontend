

export class Mastercourse
{
MasterCourse_Id:number;
MasterCourse_Name:string;
constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

