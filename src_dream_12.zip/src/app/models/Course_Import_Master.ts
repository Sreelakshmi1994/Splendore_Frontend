export class Course_Import_Master
{
Course_Import_Master_Id:number;
Date:string;
User_Id:number;
constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

