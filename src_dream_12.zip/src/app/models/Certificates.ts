export class Certificates
{
Certificates_Id:number;
Certificates_Name:string;
User_Id:number;
constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

