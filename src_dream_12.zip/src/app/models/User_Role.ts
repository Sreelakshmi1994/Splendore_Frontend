export class User_Role
{
User_Role_Id:number;
User_Role_Name:string;
Role_Under_Id:number;
constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

