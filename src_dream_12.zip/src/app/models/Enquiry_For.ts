export class Enquiry_For
{
    Enquiry_For_Id:number;
    Enquiry_For_Name:string;
constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

