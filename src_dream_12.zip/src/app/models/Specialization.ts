export class Specialization
{
Specialization_Id:number;
Specialization_Name:string;
User_Id:number;
constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

