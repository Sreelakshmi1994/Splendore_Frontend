export class Purchase_Status
{
    Purchase_Status_Id:number;
    Purchase_Status_Name:string;
DeleteStatus:number;
constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

