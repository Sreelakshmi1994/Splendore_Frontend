export class Certificate_Request
{
Certificate_Request_Id:number;
Student_Id:number;
Date:string;
Certificates_Id:number;
Status:number;
constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

