export class Exam
{
    Exam_Id:number;
    Exam_Name:string;
constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

