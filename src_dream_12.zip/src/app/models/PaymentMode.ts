export class PaymentMode
{
Payment_Mode_Id:number;
Payment_Mode_Name:string;
constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

