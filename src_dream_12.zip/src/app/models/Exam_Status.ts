export class Exam_Status
{
Exam_Status_Id:number;
Exam_Status_Name:string;
constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

