export class State_District
{
State_Id:number;
State_Name:string;
State_District_Id:number;
District_Name:string;
constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

