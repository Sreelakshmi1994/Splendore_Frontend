
export class Student_Import_Details
{
Name:string;
Email:string
Mobile:string
Last_Name:string;
Gender:string;
Address1:string;
Address2:string;
Pincode:string;
Alternative_Email:string;
// Phone_Number:string;
Alternative_Phone_Number: string;
Facebook: string;
Whatsapp: string;
College_University:string
Programme_Course:string
Intake:string
Year:string
Reference:string
Visa_Submission_Date:string
Activity:string
Visa_Outcome:string
Agent:string
Status_Details:string
Remarks:string
Date :string;
College_Name:string;
Qualification:string;
Location:string;
Student_Name:string;
Gender_Name:string;
Father_Whatsapp:string;
Sl_No:number
Admission_Branch:string
Course:string
Mode_of_Study:string
Offline_Branch:string
Admission_Date:string
Total_Fees:number
Amount:number
First_Installment_Amount:number
First_Installment_Date:string
First_Installment_To_Account:string
Second_Installment_Amount:number
Second_Installment_Date:string
Second_Installment_To_Account:string
Third_Installment_Amount:number
Third_Installment_Date:string
Third_Installment_To_Account:string

Fourth_Installment_Amount:number
Fourth_Installment_Date:string
Fourth_Installment_To_Account:string

Fifth_Installment_Amount:number
Fifth_Installment_Date:string
Fifth_Installment_To_Account:string

Sixth_Installment_Amount:number
Sixth_Installment_Date:string
Sixth_Installment_To_Account:string

Seventh_Installment_Amount:number
Seventh_Installment_Date:string
Seventh_Installment_To_Account:string




Balance:number
constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

