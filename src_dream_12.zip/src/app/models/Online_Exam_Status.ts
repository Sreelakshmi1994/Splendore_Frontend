export class Online_Exam_Status
{
Online_Exam_Status_Id:number;
Online_Exam_Status_Name:string;
constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

