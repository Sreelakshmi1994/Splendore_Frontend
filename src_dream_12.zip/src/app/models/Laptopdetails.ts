export class Laptopdetails
{
    Laptop_details_Id:number;
    Laptop_details_Name:string;

constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

