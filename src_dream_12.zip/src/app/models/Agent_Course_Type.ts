export class Agent_Course_Type
{
Agent_Course_Type_Id:number;
Agent_Id:number;
Course_Type_Id:number;
Cousrse_Type_Name:string;
constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

