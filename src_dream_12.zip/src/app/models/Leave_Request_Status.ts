export class Leave_Request_Status
{
Leave_Request_Status_Id:number;
Leave_Request_Status_Name:string;
Users_Id:number;
constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

