export class Account_Type
{
Account_Type_Id:number;
Account_Type_Name:string;

constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

