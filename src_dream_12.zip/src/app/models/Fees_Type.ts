export class Fees_Type
{
Fees_Type_Id:number;
Fees_Type_Name:string;
No_Of_Installment:number;
User_Id:number;;
constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

