export class Account_Years
{
Account_Years_Id:number;
Account_Year:string;
YearFrom:Date;
YearTo:Date;
constructor(values: Object = {})  
{
Object.assign(this, values) 
}
}

